package lab_2;
import java.util.Scanner;
public class l_3ponchuation {

	public static void main(String[] args) {
		int count = 0;
		String str;
		Scanner AD = new Scanner(System.in);
		System.out.println("Enter the test that you want to count");
		str = AD.next();
		for (int i = 0; i<str.length();i++)
		{   
            //Checks whether given character is punctuation mark  
			 if(str.charAt(i) == '!' || str.charAt(i) == ',' || str.charAt(i) == ';' || str.charAt(i) == '.' || str.charAt(i) == '?' || str.charAt(i) == '-' ||  
	         str.charAt(i) == '\'' || str.charAt(i) == '\"' || str.charAt(i) == ':')   
			 count++;  
	          
        
		}
		System.out.println("total no of ponchuation is: "+count);

	}

}
