package lab_2;
import java.util.Scanner;
import java.text.NumberFormat;
//import java.text.NumberFormate;
public class l_1 {

	public static void main(String[] args) {
		Double currentSalary; // emplyees current salary
		Double raise;		//amount of the raise
		Double newSalary;	// new salary for the employee
		String rating;		//performance rating
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the current Salary: ");
		currentSalary = scan.nextDouble();
		System.out.println("Enter the performance rating(Exellent, Good or poor)");
		rating = scan.next();
		
		// computer the raise using if ....
		if (rating.equals("Excellent")) {
			raise = currentSalary*0.06; 
			newSalary = currentSalary + raise; 
		}
		else if (rating.equals("Good")) {
			raise = currentSalary *0.04;
			newSalary = currentSalary + raise;
		}
		else
		{
			raise = currentSalary*0.015;
			newSalary = currentSalary + raise;
		}
		
		
		// print the result
		
		NumberFormat money = NumberFormat.getCurrencyInstance();
		System.out.println();
		System.out.println("Current salary:  " +money.format(currentSalary));
		System.out.println("Amaount of your raise: "+money.format(raise));
		System.out.println("your new salary is: "+money.format(newSalary));

	}

}
