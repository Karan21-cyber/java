package lab_2;
import java.util.Scanner;
import java.util.Random;


 class l_2 {

	public static void main(String[] args) {
	String personPlay;
	String computerPlay = null;
	int computerINt;
	Scanner Scan = new Scanner(System.in);
	Random generator = new Random();
	
	String[] arr = {"R","P","S"};
	System.out.println("PLEASE ENTER TO PLAY GAME: \n r for rock \n p for paper and \n r for rock");
	personPlay = Scan.next().toUpperCase();
	Random diwash = new Random();
	
	computerINt = diwash.nextInt(0,4);
	switch(computerINt) {
	case 1:
		computerPlay = "R";
		break;
	case 2:
		computerPlay = "P";
		break;
	case 3:
		computerPlay = "S";
		break;
	default:
		System.out.println("System Failure");
	
	} 	
	
	if (personPlay == computerPlay) {
		System.out.println("the gamme is tie becaues you got same ");
		System.out.println("you got "+ personPlay +" and computer got "+ computerPlay);
	}
	else if(personPlay == "R" && computerPlay =="P") {
		System.out.println("you won...!");
		System.out.println("you got "+ personPlay +" and computer got "+ computerPlay);
				
	}
	else if(personPlay == "R" && computerPlay =="S") {
		System.out.println("you loose...!");
		System.out.println("you got "+ personPlay +" and computer got "+ computerPlay);
		
		
	}
	else if(personPlay == "P" && computerPlay =="S") {
		System.out.println("you loose...!");
		System.out.println("you got "+ personPlay +" and computer got "+ computerPlay);
		
		
	}
	else if(personPlay == "P" && computerPlay =="R") {
		System.out.println("you WON...!");
		System.out.println("you got "+ personPlay +" and computer got "+ computerPlay);
		
		
	}
	else if(personPlay == "S" && computerPlay =="P") {
		System.out.println("you won...!");
		System.out.println("you got "+ personPlay +" and computer got "+ computerPlay);
		
		
	}
	else if(personPlay == "S" && computerPlay =="R") {
		System.out.println("you LOOSE...!");
		System.out.println("you got "+ personPlay +" and computer got "+ computerPlay);

	}
	
	
}

}
