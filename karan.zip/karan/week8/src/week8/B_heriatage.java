package week8;

public class B_heriatage  extends A_inheritage{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B_heriatage b  = new B_heriatage () ;
		System.out.println("sds"+ b.x);
		

	}

}
