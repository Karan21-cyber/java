package week8;

public class Array2 {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub

		Student s1 = new Student  (101,"diwash");
		Student s2 = new Student  (108,"mukesg ");
		Student s3 = new Student  (107,"danu");
		Student s4 = new Student  (106,"dsash");
		Student s5 = new Student  (105,"dwash");
		Student[] list = {s1,s2,s3,s4,s5};// creating an array of Student
		
		Student [] stdlist = {
		new Student	(101,"diwash"),
		new Student (108,"name"),
		new Student (107,"danu")
		};
		
		Student [] names = {
				new Student	("diwash"),
				new Student ("mukesg"),
				new Student ("danu"),
				new Student ("dwash")
		};	
		
		
		
		for (Student s : names)
		{
			System.out.println(s);// this will give the adres of the memory 
		
		}
		
		
	}

}
