package week8;

public class Array3 {
	static void min(int[] arr)
	{
		int min = arr[0];
		for (int i  = 0 ; i< arr.length; i++)
	{
			if (min > arr[i])
			{
				min = arr[i];
			}
	}
		System.out.println("minimum is "+ min);
	}
	static void max(int[] arr)
	{
		int max = arr[0];
		for (int i  = 0 ; i< arr.length; i++)
	{
			if (max < arr[i])
			{
				max = arr[i];
			}
	}
		System.out.println("maximun is "+ max);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] num = {4,23,25,76,2};
		min(num);//
		min(new int[] {1,3,4,5,6,7,8,2});// pasing the anomous array
		
		int[] n = new int[] {1,3,4,5};// not composary is needed
		max(n);
		max(num);
		
		
	}
	
	

}
