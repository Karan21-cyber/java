package week8;

public class B  extends object_class{
 int y = 20; 
 B(){
	 super();
	 y = 50;
 }
 B(int y){
	 super(50);// 
	 this.y = y; 
 }
	public void display() 
	
	{
		// caling prperty of super key words
		super.display(); // caling the parent class method 
		System.out.println("y:"+y);
	}
public  static void main(String[] args) {
		// TODO Auto-generated method stub
		B b = new B();
		b.display();
		
		B b1 = new B(50) ;// caling the parematerized constructor
		b1.display();
	}

}
