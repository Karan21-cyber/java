package week8;

public class object_class {
int x;
object_class()
{
////x = 10;	
System.out.println("i am form class A");
}
object_class (int x)
{
	this();
	this.x = x; 	
}

public void display()
{
	System.out.println("x:"+x);
	
}
public static void main(String[] args) {
	
}
}
