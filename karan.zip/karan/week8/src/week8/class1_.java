package week8;

public class class1_ {
	int x = 20 ;
	static int y = 50;
	//Test()// default constructor 
	//{
		
	//}
	Test(int x)// parameterise constructoe
	{
		this.x = x;
	}
	
	
	public void display()
	{
		System.out.println("x = "+ x);
	}

	public static void main(String[] args) {
		Test t;
		t = new Test();// declearing a refreace will not allocaet 
		
		Test t1 = new Test(10);
		t1.display();
	}

}
