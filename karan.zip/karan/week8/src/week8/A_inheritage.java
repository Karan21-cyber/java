package week8;

public class A_inheritage {
	int x  = 30; 
	public static void main(String[] args) {
 
	}

}
