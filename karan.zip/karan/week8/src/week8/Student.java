package week8;

public class Student {
	int rollno;
	String name;
	Student(int rollno, String name){
		this.rollno = rollno;
		this.name = name;
		
	}
	
	Student(String name)
	{
		this.name = name;
	}
	public String toString()
	{
		//return "name ="+ name;
		// for rool no  alsi 
		return "[rono l = "+ rollno+",name ="+ name+"]";
		
	}
	

}
