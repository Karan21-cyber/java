package class1;

public class methods {

	private int x;// instance variable 
	private int y;
	
	public int getx()// accesor getter
	{
		return x;
	}
	public void  setx(int x)
	{
		this.x = x; // this keywords represent current class object
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
