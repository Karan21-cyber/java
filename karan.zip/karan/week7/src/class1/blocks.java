package class1;

public class blocks {
	//instance initilazier block
	{
		System.out.println(" Hi forom blocks "); 
	}
	
	static {
		System.out.println("hi form static");
	}

	public static void main(String[] args) {
		System.out.println("HI fomm block");
		
		new blocks();//creatin an object
		
		
		// this static block is run first than other block method. 
		

	}

}
