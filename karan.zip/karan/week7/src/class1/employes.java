package class1;

public class employes {
	int eid;
	string name;
	string dept;
	int salary;
	void display()
	{
		System.out.println("employer id = "+ eid);
		System.out.println("nane = "+ name);
		System.out.println("deparmet = "+ dept);
		System.out.println("employes salary = "+ salary);
	}
public employes(int id, string n, string d, int s )
{
	eid = id;
	name = n;
	dept = d;
	salary = s;
	
}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
 employee ramesh = nae employee(1001,"ramesh","it",35000)
	ramesh.display(); 
	}

}
