package practies_class;

public class Studenet_data {
	int rollno;
	String name;
	String address;
	int age;
	
	public void display_data() 
		{
			System.out.println("Roll no : "+ rollno);
			System.out.println("Name : "+ name);
			System.out.println("Address : "+ address);
			System.out.println("Age : "+ age);
		}
		
	Studenet_data (int roll, String names, String add, int ages)
	{
	rollno = roll;
	name = names ;
	address = add;
	age = ages;
	}
	
	
	
	public static void main(String[] args) 
	
		{
			
			// creating an instancee of class students
			Studenet_data ram = new Studenet_data(100,"Ram","POkhara",21);
			ram.display_data();  // calling the behavior of the object Ram
			
		}
	

}
