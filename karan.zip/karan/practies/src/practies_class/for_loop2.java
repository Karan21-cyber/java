package practies_class;
/** enhance for loop
 * enhance for is introduced in java.
 * it is used for retrieving data from the college
 * it is a short form of loop.
  */

public class for_loop2 {

	public static void main(String[] args) {
		int[] num = {1,2,3,4,5};
		/*for (int i = 0; i<5; i++)
		 {
		 System.out.println(num[i]);
		 }*/
		 
		for (int x : num)
		{
			System.out.println(x);
		}
		

	}

}
