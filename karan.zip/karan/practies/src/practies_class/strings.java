package practies_class;

public class strings {

	public static void main(String[] args) {
		int x = 10; // local variable: creating in the stack area
		strings obj;
		obj = new strings();
		
		String name;
		name = "TBC";
		System.out.printf(name);
		System.out.printf("%d", x);
		var address = "Butwal";

	}

}
