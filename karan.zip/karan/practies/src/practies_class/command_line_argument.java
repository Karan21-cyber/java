package practies_class;

public class command_line_argument {
	// The String array inside the main method is used for command line arguments
	public static void main(String[] args) {
		String name;
		name = agrs[0];// comand line arguments -Arguments are given to the runtime
		System.out.println("Hi "+ name);
		System.out.println("Welcome Diwash");
		

	}

}
