package practies_class;

public class for_loop {

	public static void main(String[] args) {
		for (int x = 1; x <=10; x++)//inital point,range, increment
		{
			System.out.println(x);
		}

	}

}
