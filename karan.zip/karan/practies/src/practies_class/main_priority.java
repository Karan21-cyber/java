package practies_class;

public class main_priority {
	{
	System.out.println("Hi form IIB block");
	}
	public static void main(String[] args) {
	    //new block(); // creating an object
		System.out.println("Hi form main Block");

	}
	//static initializer block(SIB)// it has main proiority
	static {
		System.out.println("Hi form ststic block");
	} 

}
