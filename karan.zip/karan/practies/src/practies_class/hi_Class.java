package practies_class;

public class hi_Class {

	public static void main(String[] args) {
			String name = "Diwash";
			
			String adress = "Butwal";
			String email = "diwash.tharu.ch@gmail.com";
			String num = "10";
			num.concat("40");
			int x = 10;
			x = 20;
			
			System.out.println("Name: "+ name);
			System.out.println("Address: "+ adress);
			System.out.println("Emial: "+ email);
			System.out.println("number: "+ num);
			System.out.println("NUmber: "+ x); 
			

	}

}
