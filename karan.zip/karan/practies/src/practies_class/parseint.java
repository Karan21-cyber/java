package practies_class;

public class parseint {

	public static void main(String[] args) {
			int x, y, sum = 0;
			x = Integer.parseInt(args[0]);// input is string.it must be cponvert to integer
			y = Integer.parseInt(args[1]);
			sum = x + y; // adds two intehers
			System.out.println("Addition of "+ args[0] +" and " + args[1]+" = "+ sum);

	}

}
/*
 * this code is run by using in option run after that cliclk 
 * run as configuration 
 * after that click on agruments and emter 
 * this program is ask first  ask or send data to the compiler so */
 */