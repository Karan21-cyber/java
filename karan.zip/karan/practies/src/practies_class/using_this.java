package practies_class;

public class using_this {
	private int x; // instance variable
	private int y;
	
	public int getX() // accessor / getter
	{
		return x;
	}

	public void setX(int x)   // local variable
	{
		this.x = x;  // (this) keyword represents current class object
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
