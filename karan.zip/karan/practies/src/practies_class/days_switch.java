package practies_class;
import java.util.Scanner;

public class days_switch {

	public static void main(String[] args) {
		String s;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter name of the week:");
		s = sc.next();
		/*
		 * in c/c++, condition in a switch must be an integer or charater
		 * an expression that result an integer or charcter 
		 * also case must be an integer or character
		 * can in java we can use string also
		 * */
         switch(s)
         {         
         case "saturday":
        	 System.out.println("No class today");
         case "sunday":	 
         case "monday":
         case "tuesday":
         case "wednesday":
         case "thursday":
         case "friday":
        	 System.out.println("classes today");
        	 break;
        	 /*default ststement cab be written anywhere inside the switch
        	  * default ststement
        	  * 
        	  * */
        	 default:
        		 System.out.println("please enter valid  day only");
        		 break;
         }
         
	}
	

}
