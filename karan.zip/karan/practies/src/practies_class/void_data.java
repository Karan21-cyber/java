package practies_class;

public class void_data {
	// decleration of instance variable 
	private int eid;
	private String name;
	private String dept;
	private int salary;
	
	public void  display_data() {
		System.out.println("Employess ID: " + eid);
		System.out.println("Name: "+ name);
		System.out.println("Departure: "+ dept);
		System.out.println("Salary: "+ salary);
	}
	//constructor
		public void_data(int id, String n, String d, int s) {
			eid = id;
			name = n;
			dept = d;
			salary = s;
			
		}
		public static void main(String[] args) {
			void_data emp = new void_data(101,"karan","IT",35000);
			emp.display_data();//calling the method
		 
		

	}

}
