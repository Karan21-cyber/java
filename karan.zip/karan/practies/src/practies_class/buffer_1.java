package practies_class;
import java.io.*;
public class buffer_1 {

	public static void main(String[] args)throws Exception{
		String s;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("What is your name");
		s = br.readLine();
		System.out.println("The requires answer is: "+ s);
		

	}

}
