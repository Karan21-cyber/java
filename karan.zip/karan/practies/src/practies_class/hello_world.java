package practies_class;

public class hello_world {

	public static void main(String[] args) {
		System.out.println("Hellow World");
		int i,a;
		for (i = 1; i<6;i++)
		{
			for (a = i; a < 6; a++)
			{
				System.out.println(i);
			}System.out.println("\n");
		}

	}

}
