package practies_class;
// To ask the user to input a number

//In java import statements are used
import java.util.Scanner;

public class INPUTNUM {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// Sysytem.in: represent the Keyboard
		System.out.println("Input a number: ");
		int num;
		num = sc.nextInt();
		System.out.println("The value input by the user is "+num);
		num++;
		System.out.println("The incremented value is "+ num);

	}

}
