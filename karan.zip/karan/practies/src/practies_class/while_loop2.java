package practies_class;
//Wap to Print first 10 natural number.  
public class while_loop2 {

	public static void main(String[] args) {
		int x = 1; //1.initial point 
		while(x <=10) //2. condition
		{
			System.out.println(x);//3.task
			x++;//increment
		}	
	}

}
