package practies_class;

import java.util.Scanner;
import java.util.scanner;

public class system_in {

	public static void main(String[] args) {
		Scanner obj = new Scanner(System.in);
		double x, y, sum = 0;
		System.out.print("Enter a number: ");
		x = obj.nextDouble();
		System.out.print("Enter another number: ");
		y = obj.nextDouble();
		sum = x+y;
		System.out.println("Additional of two number is "+ sum);
		
		

	}

}
