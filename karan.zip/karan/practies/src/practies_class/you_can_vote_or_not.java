package practies_class;
import java.util.Scanner;
public class you_can_vote_or_not {

	public static void main(String[] args) {
		Scanner obj = new Scanner(System.in);
		int age;
		String name;
		System.out.println("Enter your age:");
		age = obj.nextInt();
		 if (age >= 18) {
			 System.out.println("you are eligible for voting");
			 
		 }else {
			 System.out.println("you are  not eligible for voting");
		 }
		 
			 
	}

}
