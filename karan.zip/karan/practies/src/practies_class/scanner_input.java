package practies_class;
import java.util.Scanner;
public class scanner_input {

	public static void main(String[] args) {
		String s;
		Scanner sc = new Scanner(System.in);
		System.out.println("PLease enter your name: ");
		s = sc.next();
		System.out.println("your name is: " + s);
	}

}
