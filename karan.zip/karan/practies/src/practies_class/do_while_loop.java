package practies_class;

public class do_while_loop {

	public static void main(String[] args) {
		int x = 1;//initial point
		do
		{
			System.out.println(x);//2.task
			x++; //3. increment
		}while(x<=10);//4.condition 	
			

	}

}
