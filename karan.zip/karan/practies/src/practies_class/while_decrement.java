package practies_class;
//Wap to print natural number form 10 to 1
public class while_decrement {

	public static void main(String[] args) {
		int x = 10;// 1.initial point
		while (x >= 1)
		{
			System.out.println(x);
			x--;
		}
		

	}

}
