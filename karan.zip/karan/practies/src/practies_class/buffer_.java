package practies_class;
import java.io.*;
public class buffer_ {

	public static void main(String[] args)throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int a , b, div;
		System.out.println("enter the first number");
		a = Integer.parseInt(br.readLine());
		
		System.out.println("enter the second number");
		b = Integer.parseInt(br.readLine());
		div = a/b;
		System.out.println("The answe of the division is:" + div);
		
	}

}
