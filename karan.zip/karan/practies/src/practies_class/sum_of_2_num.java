package practies_class;
import java.util.Scanner;
public class sum_of_2_num {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("sum of two nuber is:");
		System.out.println("Enter first number:");
		int num1, num2, sum;
		num1 = sc.nextInt();
		System.out.println("Enter the second number:");
		num2 = sc.nextInt();
		sum = num1 + num2;
		System.out.println("The value of two number = "+ sum);
		
		

	}

}
