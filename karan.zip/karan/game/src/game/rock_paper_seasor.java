package game;
import java.util.Scanner;
import java.util.Random;

public class rock_paper_seasor {

	public static void main(String[] args) {
		Scanner ab = new Scanner(System.in);
		Random rand = new Random();
		
		System.out.println("This is the game of rock paper and seasro");
		
		String user_input;
		user_input = ab.next();
		String[] computer = {"Rock","paper","Scissor"};
		System.out.println("Thank for providing the input to the user."+ user_input);

	}

}
