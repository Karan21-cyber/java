package lab_3;
import java.util.Scanner;
public class StringPlay {

	public static void main(String[] args) {
		String college = new String("Leeds Beckett University");
		String town = new String("Anytown, UK");
		int stringLength;
		String change1, change2, change3,s;
		stringLength = college.length();
		System.out.println("college contains " + stringLength + " characters.");
		System.out.println(college.toLowerCase());
		System.out.println(college.toLowerCase().replace("e", "*"));
		s =college.concat(town);
	    System.out.println ("The final string is " + s);
	}

}
