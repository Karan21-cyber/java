package lab_1;
import java.util.Scanner;
import java.lang.Math;
public class square {

	public static void main(String[] args) {
		Double a,b;
		Scanner AD = new Scanner(System.in);
		System.out.println("Enter the number that you want to print");
		a = AD.nextDouble();
		b = Math.pow(a,2);
		//b = a*a;
		System.out.println("The square form of" + a +" IS :" +b);
		
	}

}
