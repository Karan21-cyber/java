package lab_1;
import java.util.Scanner;
public class factor {

	public static void main(String[] args) {
		double data, data2, data3;
		Scanner Ad = new Scanner(System.in);
		System.out.println("Please ente first data:");
		data = Ad.nextDouble();
		System.out.println("Please enter second data:");
		data2 = Ad.nextDouble();
		data3 = data/data2;
		System.out.println("The factor of the value of data" + data3);
		
		
		

	}

}
