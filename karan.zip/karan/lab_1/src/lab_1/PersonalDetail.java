package lab_1;
import java.util.Scanner;
public class PersonalDetail {

	public static void main(String[] args) {
	int age; 
	String name, address, phon;
	Scanner ad = new Scanner(System.in);
	System.out.println("please enter your name:");
	name = ad.next();
	System.out.println("Please enter your address");
	address = ad.next();
	System.out.println("pleas enter your age");
	age = ad.nextInt();
	System.out.println("please enetr your phone number");
	phon = ad.next();
	System.out.println("name = "+ name ); 
	System.out.println("address:"+ address); 
	System.out.println("phone no:"+phon); 
	System.out.println("age="+age ); 
	}

}
