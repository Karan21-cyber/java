package lab_1;
import java.io.*;
import Java.util.*;
public class table_task {

	public static void main(String[] args) {
		String name;
		int lab, bonus,i,num;
		//creating new lists objects
		List<String> nms = new ArrayList<>();
		LIst<Integer> labs = new ArrayList<>();
		List<Integer>bns = new ArrayList<>();
		List<Integer> total = new ArratList<>();
		// creating the object 
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter the number of people to get the table");
		num = Integer.parseInt(br.readLine());
		// this will loop the number of student detail and store the data in the lsit
		for (i = 1; i <=num;i++)
		{
			System.out.print("Enter your name: ");
			name = br.readLine();
			nms.add(name);
			
			System.out.print("Enter your Lab Marks: ");
			lab = Integer.parseInt(br.readLine());
			labs.add(lab);
			
			System.out.print("Enter your Bonus Marks: ");
			bonus = Integer.parseInt(br.readLine());	
			bns.add(bonus);
			
			System.out.println("Data Entered Successfully");
			System.out.println("");	
		}
		
		
		// Creating the Table
				System.out.println("///////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
				System.out.println("==          Student Points          ==");
				System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\///////////////////");
				
				System.out.println("");
				System.out.println("Name"+"\t\t"+"Lab"+"\t"+"Bonus"+"\t"+"Total");
				System.out.println("----\t\t---\t-----\t-----");
				
				// this will return the output from the list
				for(i = 0; i <= num;i++) {
					int sum = labs.get(i)+bns.get(i);
					total.add(sum);
					System.out.println(nms.get(i)+"\t\t"+labs.get(i)+"\t"+bns.get(i)+"\t"+total.get(i));
				}				
		
	}
	

}
