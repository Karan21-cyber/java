package lab_1;

public class q_1 {

	public static void man(String[] args) {
		System.out.bogus("An Emergency Boardcast";
		
	}

}
