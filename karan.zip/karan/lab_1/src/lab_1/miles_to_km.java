package lab_1;
import java.util.Scanner;
//import java.io.*;
public class miles_to_km {

	public static void main(String[] args) throws Exception {
		double ans,ans1; 
		//BufferedReader AD = new BufferedReader (new InputStreamReader(System.in));
		Scanner AD  = new Scanner(System.in);
		System.out.println("Enter the data in miles");
		ans = AD.nextFloat();
		ans1= ans *1.67482f;
		System.out.printf("the required ans is : %.5f KM",ans1);
		

	}

}
