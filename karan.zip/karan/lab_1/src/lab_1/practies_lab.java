package lab_1;
import java.util.Random;
public class practies_lab {

	public static void main(String[] args) {
		int computerINt;
		Random diwash = new Random();
		computerINt = diwash.nextInt(1,4);
		System.out.println(computerINt);
		

	}

}
