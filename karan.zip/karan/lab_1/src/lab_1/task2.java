package lab_1;
//import java.text.DecimalFormat;
//import java.text.NumberFormat;
import java.util.Scanner;
public class task2 {

	public static void main(String[] args) {
		double vall,
		 val2, val3;
		double average;
	//	NumberFormat ad = new DecimalFormat("#0.0000000");
		Scanner AD = new Scanner(System.in);
		System.out.println("Please enete the three integer and "+"i will make there average");
		System.out.println("please enter the first number");
		vall = AD.nextDouble();
		System.out.println("PLease enter the second number");
		val2 = AD.nextDouble();
		System.out.println("please enter the third number");
		val3 = AD.nextDouble();
		average = (vall+val2+ val3)/3;
		System.out.println("Please enete the three integer and \"+\"i will make there average"); 
		System.out.println("Enter the first values: "+ vall);
		System.out.println("Enter the second value: "+ val2);
		System.out.println("Enter the second value: "+ val3);
		System.out.println("The avarage is "+ average); 
	}
	

}
