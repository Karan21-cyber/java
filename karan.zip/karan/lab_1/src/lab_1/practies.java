package lab_1;

public class practies {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
