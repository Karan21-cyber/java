package mcq;

public class p2 {

	public static void main(String[] args) {
		         Object obj = new Object();
			     System.out.print(obj.getclass());
		        
		   

	}

}
