package mcq;

public class if_statement {

	public static void main(String[] args) {
		 int a = 20;
		 if (a<0)
			 System.out.println("your are true yw you can di it" );
		 else
			 System.out.println("sorry you are wrong");

	}

}
