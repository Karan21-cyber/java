package mcq;

public class object_class {
	String firstname;
	String Lastname;
	double gpa;
	String major;
	int age;
	boolean ondiwash;

	public static void main(String[] args) {
		object_class diwash =  new object_class();
		diwash.firstname = "diwash";
		diwash.Lastname = "tharu";
		diwash.age = 22;
		diwash.gpa = 2.2;
		System.out.println(diwash.firstname);
        sysout
	}

}
